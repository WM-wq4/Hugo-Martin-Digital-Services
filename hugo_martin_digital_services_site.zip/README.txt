Hugo Martin Digital Services — static website

Files:
- index.html — complete responsive website

Fastest way to publish:
1. Upload index.html to a static hosting provider such as GitHub Pages, Netlify, or Cloudflare Pages.
2. Make sure the final URL is public and does not require login.
3. Open it in a private/incognito window to confirm.
4. Use that public URL for Stripe verification.

The site intentionally contains no fake testimonials, client logos, physical address, or unsupported claims.
